# SRT 白板动画 — Qoder Plugin

**Source**: [github.com/geeklee/srt-whiteboard-animation](https://github.com/geeklee/srt-whiteboard-animation)（MIT License，作者 geeklee / 江哥是老登啊）

把 SRT 字幕做成**暖米黄纸张底的白板手绘动画**：解析字幕 → 分镜策略 → 统一风格线稿 → 语义分区标注 → 浏览器预览台调时序 → 流式笔迹渲染 MP4 → 多幕合并。

编排沿用分区遮罩揭示（`annotation.json` / `sequence` / `startMs` / `protectedRegions`），画法是每个区域内连续流动的 stream 笔迹（起笔 `ink` 铺线稿 → 添彩 `color`），所有区域共享一张持久画布。

## 包含技能

| 技能 | 用途 |
|---|---|
| `srt-whiteboard-animation` | SRT 字幕 → 白板手绘动画完整工作流（7 步，每步强制停下等用户确认） |

单个技能、单一工作流，因此不做拆分。

## 文件结构

```
srt-whiteboard-animation/
├── .qoder-plugin/
│   └── plugin.json
├── README.md
├── assets/
│   └── avatar.svg                      # 本地图标（转换时新绘制，非上游素材）
└── skills/
    └── srt-whiteboard-animation/
        ├── SKILL.md                    # 上游工作流，原样保留
        ├── LICENSE                     # 上游 MIT 许可证
        ├── agents/openai.yaml          # 上游 Codex 界面元数据（保留为内容文件，未注册为 Qoder agent）
        ├── assets/
        │   ├── preview.html            # 本地预览台（无需服务器，Chrome/Edge 直接打开）
        │   └── drawing-hand.png        # 渲染用手部素材（笔杆含上游标识）
        └── scripts/
            ├── prepare_env.py          # 建 skill 内 .venv 并补依赖，输出 ENV_PY
            ├── parse_srt.py            # SRT 解析 + 25–35 秒/幕分镜建议
            ├── render_annotation_preview.py  # 区域编号检查图
            ├── render_stream_whiteboard.py   # 流式笔迹单幕渲染器
            ├── stream_render.py        # 笔迹绘制内核（被上一文件 import，不可单独删除）
            └── merge_scenes.py         # 多幕合并
```

## 前置依赖

渲染脚本需要 Python 3 与隔离虚拟环境，首次使用先执行（依赖会装进技能目录下的 `.venv/`）：

```bash
cd skills/srt-whiteboard-animation
python scripts/prepare_env.py --check   # 仅探测，成功时末行输出 ENV_PY=<解释器路径>
python scripts/prepare_env.py           # 缺则建 .venv 并安装依赖
```

自动安装的包：`opencv-python`、`numpy`、`av`（PyAV，H.264 编码走纯 pip，无需系统 ffmpeg）、`Pillow`。

可选：系统 `ffmpeg`。`merge_scenes.py` 优先用它做 `-c copy` 无损拼接，没有则回退 PyAV 逐帧重编码。

预览台的"保存写回原 JSON"依赖浏览器 File System Access API，请用 Chrome 或 Edge；其它浏览器只能下载后手动覆盖。

## 省略内容与原因

| 省略项 | 原因 |
|---|---|
| `examples/`（约 11 MB：2 个 GIF、2 个 PNG、1 个 MP4、1 个 annotation.json） | 仅上游 README 的演示素材，`SKILL.md` 工作流不引用它们。需要看效果请回原仓库：<https://github.com/geeklee/srt-whiteboard-animation/tree/main/examples> |
| `.gitignore` | 上游仓库的入库规则（忽略 `.venv/`、`__pycache__/`、`*.mp4`），对已安装的插件包无意义 |

插件包体积因此约 960 KB。`SKILL.md`、6 个脚本、预览台 HTML 与手部素材均完整收录，仅 `render_annotation_preview.py` 有一处本地修复（见下）。

## 本地改动

| 文件 | 改动 | 原因 |
|---|---|---|
| `scripts/render_annotation_preview.py` | 硬编码的 `C:/Windows/Fonts/msyh.ttc` 改为跨平台字体探测（新增 `FONT_CANDIDATES` + `load_font()`，Windows 路径仍优先），找不到任何中文字体时回退 PIL 默认字体 | 上游只在 Windows 上跑过；macOS/Linux 上生成区域检查图会 `OSError: cannot open resource` 直接崩溃 |

其余 10 个上游文件保持逐字节原样。因该修复改变了分发包内容，版本号从 0.1.0 提升到 0.1.1。

> 素材提示：`assets/drawing-hand.png` 笔杆上印有上游作者昵称文字。`SKILL.md` 要求画面内不得出现任何文字，该标识会随手部出现在每一帧。若不需要它，用图像工具擦除笔杆文字后把清理版传给渲染脚本的第 4 个位置参数（手部素材路径），或用 `--bare-tip` 只画笔尖。

## 触发方式

对 Agent 说类似需求即可命中技能：把这份字幕做成白板手绘动画 / SRT 生成白板动画 / 按字幕分镜画手绘。

技能内置**强制确认关卡**：每一步完成后必须等用户明确确认才进入下一步，不会一次跑完烧掉渲染成本。

## 验证记录

- 结构校验：`validate_qoder_plugin.py .agents/skills/srt-whiteboard-animation` → `OK: no issues found`（exit 0）
- 一致性：11 个上游文件中 10 个（`SKILL.md`、`LICENSE`、`agents/openai.yaml`、2 个 assets、5 个 scripts）与源仓库 `cmp` 逐字节相同；`render_annotation_preview.py` 为本地修复版，见「本地改动」
- 语法：6 个脚本 `python3 -m py_compile` 全部通过
- 从插件路径实跑 `parse_srt.py` 解析 3 条字幕的测试 SRT，正确输出分镜建议与 JSON
- `prepare_env.py` 已在插件目录内建出 `skills/srt-whiteboard-animation/.venv`（opencv-python / numpy / av / Pillow）
- **端到端实跑（macOS arm64）**：`render_annotation_preview.py` 生成区域检查图 → `render_stream_whiteboard.py --ink-path grid --color-fill contour-wipe` 渲染 2 幕，各得 1080×570 @60 fps、29.50 s / 30.00 s 的 H.264 MP4 → `merge_scenes.py` 合并成一条成片。逐帧抽查确认分区遮罩不变量成立：已开始区域完整落墨、未开始区域完全隐藏、收尾停在整图上
- 未验证：Windows / Linux 上的运行表现；`preview.html` 预览台的浏览器交互（其"打开文件夹"需原生文件选择手势，无法脚本化）
- 打包分发：插件目录已压成 zip（`.qoder-plugin/plugin.json` 位于压缩包根，非嵌套目录），对 zip 再跑一次校验同样 `OK: no issues found`
